# degrees to radians

Converts a number from degrees to radians

```blocks
console.log(spriteutils.degreesToRadians(360))
```

```package
spriteutils=github:jwunderl/arcade-sprite-util
```