# radians to degrees

Converts a number from radians to degrees

```blocks
console.log(spriteutils.radiansToDegrees(3.1415926535897932384))
```

```package
spriteutils=github:jwunderl/arcade-sprite-util
```