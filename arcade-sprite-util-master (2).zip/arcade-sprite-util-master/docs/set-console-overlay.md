# set console overlay

Set whether the console should be displayed on the screen (on) or not (off).

```blocks
spriteutils.setConsoleOverlay(true);
console.log("Hello!!");
```

```package
spriteutils=github:jwunderl/arcade-sprite-util
```